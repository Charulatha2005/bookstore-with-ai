from django.contrib import admin
from django.utils.html import format_html
from .models import Book, Category, Subscriber, CartItem, Order, OrderItem


# ─── Admin Site Customization ──────────────────────────────────────────────────

admin.site.site_header = '📚 BookChimp Admin Panel'
admin.site.site_title = 'BookChimp Admin'
admin.site.index_title = 'Welcome to BookChimp Administration'


# ─── Category Admin ────────────────────────────────────────────────────────────

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['icon', 'name', 'slug', 'book_count']
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ['name']

    def book_count(self, obj):
        count = obj.books.count()
        return format_html('<b>{}</b> books', count)
    book_count.short_description = 'Books'


# ─── Book Admin ────────────────────────────────────────────────────────────────

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = [
        'cover_thumb', 'title', 'author', 'category',
        'price', 'rating', 'stock',
        'is_best_seller', 'is_new_arrival', 'is_audiobook', 'is_featured'
    ]
    list_filter = ['category', 'is_best_seller', 'is_new_arrival', 'is_audiobook', 'is_featured', 'language']
    search_fields = ['title', 'author', 'isbn']
    list_editable = ['price', 'stock', 'is_best_seller', 'is_new_arrival', 'is_audiobook', 'is_featured']
    readonly_fields = ['created_at', 'updated_at', 'cover_preview']
    prepopulated_fields = {}
    date_hierarchy = 'published_date'
    ordering = ['-created_at']

    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'author', 'category', 'isbn')
        }),
        ('Details', {
            'fields': ('description', 'pages', 'language', 'published_date')
        }),
        ('Pricing & Stock', {
            'fields': ('price', 'stock', 'rating')
        }),
        ('Cover Image', {
            'fields': ('cover_image', 'cover_preview')
        }),
        ('Featured Sections', {
            'fields': ('is_best_seller', 'is_new_arrival', 'is_audiobook', 'is_featured'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def cover_thumb(self, obj):
        if obj.cover_image:
            return format_html(
                '<img src="{}" style="width:40px;height:55px;object-fit:cover;border-radius:4px;" />',
                obj.cover_image.url
            )
        return format_html('<div style="width:40px;height:55px;background:#e5e7eb;border-radius:4px;display:flex;align-items:center;justify-content:center;">📚</div>')
    cover_thumb.short_description = 'Cover'

    def cover_preview(self, obj):
        if obj.cover_image:
            return format_html(
                '<img src="{}" style="max-height:200px;border-radius:8px;" />',
                obj.cover_image.url
            )
        return 'No image uploaded'
    cover_preview.short_description = 'Preview'


# ─── Subscriber Admin ──────────────────────────────────────────────────────────

@admin.register(Subscriber)
class SubscriberAdmin(admin.ModelAdmin):
    list_display = ['email', 'subscribed_at', 'is_active']
    list_filter = ['is_active', 'subscribed_at']
    search_fields = ['email']
    list_editable = ['is_active']
    readonly_fields = ['subscribed_at']
    date_hierarchy = 'subscribed_at'

    actions = ['mark_active', 'mark_inactive']

    def mark_active(self, request, queryset):
        queryset.update(is_active=True)
        self.message_user(request, f'{queryset.count()} subscribers marked as active.')
    mark_active.short_description = 'Mark selected as active'

    def mark_inactive(self, request, queryset):
        queryset.update(is_active=False)
        self.message_user(request, f'{queryset.count()} subscribers marked as inactive.')
    mark_inactive.short_description = 'Mark selected as inactive'


# ─── Order Admin ───────────────────────────────────────────────────────────────

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ['book', 'quantity', 'price', 'subtotal']

    def subtotal(self, obj):
        return f'₹{obj.subtotal}'
    subtotal.short_description = 'Subtotal'


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'full_name', 'email', 'total_amount', 'status', 'payment_method', 'created_at']
    list_filter = ['status', 'payment_method', 'created_at']
    search_fields = ['full_name', 'email', 'phone']
    list_editable = ['status']
    readonly_fields = ['session_key', 'created_at']
    inlines = [OrderItemInline]
    date_hierarchy = 'created_at'

    def colored_status(self, obj):
        colors = {
            'pending': '#f59e0b',
            'confirmed': '#3b82f6',
            'shipped': '#8b5cf6',
            'delivered': '#10b981',
            'cancelled': '#ef4444',
        }
        color = colors.get(obj.status, '#6b7280')
        return format_html(
            '<span style="color:{};font-weight:bold;">{}</span>',
            color, obj.get_status_display()
        )
    colored_status.short_description = 'Status'


# ─── Cart Admin (Read-only, for debugging) ─────────────────────────────────────

@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ['session_key', 'book', 'quantity', 'added_at']
    list_filter = ['added_at']
    search_fields = ['book__title', 'session_key']
    readonly_fields = ['session_key', 'book', 'quantity', 'added_at']
