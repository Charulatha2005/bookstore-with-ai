from django.core.management.base import BaseCommand
from django.utils.text import slugify
from store.models import Category, Book
from decimal import Decimal
import datetime


CATEGORIES = [
    ('Fiction', '📖', 'Explore imaginary worlds and compelling stories.'),
    ('Non-Fiction', '📰', 'Real events, biographies, and factual books.'),
    ('Science & Technology', '🔬', 'Cutting-edge science, technology, and innovation.'),
    ('Self Help', '🌟', 'Personal growth, motivation, and life improvement.'),
    ('History', '🏛️', 'Ancient to modern history from around the world.'),
    ('Romance', '❤️', 'Love stories that warm the heart.'),
    ('Mystery & Thriller', '🔍', 'Suspenseful stories to keep you on the edge.'),
    ('Children', '🎨', 'Wonderful books for young readers.'),
    ('Business', '💼', 'Entrepreneurship, leadership, and finance.'),
    ('Education', '🎓', 'Academic and learning resources.'),
]

BOOKS = [
    # Fiction
    {
        'title': 'The Midnight Library',
        'author': 'Matt Haig',
        'category': 'Fiction',
        'description': 'Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived.',
        'price': Decimal('349.00'),
        'pages': 304,
        'rating': Decimal('4.5'),
        'is_best_seller': True,
        'is_featured': True,
        'published_date': datetime.date(2020, 8, 13),
    },
    {
        'title': 'Project Hail Mary',
        'author': 'Andy Weir',
        'category': 'Fiction',
        'description': 'A lone astronaut must save the earth from disaster. An irresistible interstellar adventure by the author of The Martian.',
        'price': Decimal('399.00'),
        'pages': 476,
        'rating': Decimal('4.8'),
        'is_best_seller': True,
        'is_new_arrival': True,
        'published_date': datetime.date(2021, 5, 4),
    },
    {
        'title': 'The Alchemist',
        'author': 'Paulo Coelho',
        'category': 'Fiction',
        'description': 'A magical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of treasure. A global phenomenon that has inspired millions.',
        'price': Decimal('199.00'),
        'pages': 208,
        'rating': Decimal('4.7'),
        'is_best_seller': True,
        'is_featured': True,
        'published_date': datetime.date(1988, 1, 1),
    },
    # Non-Fiction
    {
        'title': 'Sapiens: A Brief History of Humankind',
        'author': 'Yuval Noah Harari',
        'category': 'Non-Fiction',
        'description': 'From a renowned historian comes a groundbreaking narrative of humanity\'s creation and evolution—a #1 international bestseller.',
        'price': Decimal('449.00'),
        'pages': 443,
        'rating': Decimal('4.6'),
        'is_best_seller': True,
        'is_featured': True,
        'published_date': datetime.date(2011, 1, 1),
    },
    {
        'title': 'Thinking, Fast and Slow',
        'author': 'Daniel Kahneman',
        'category': 'Non-Fiction',
        'description': 'Kahneman takes us on a groundbreaking tour of the mind and explains the two systems that drive the way we think.',
        'price': Decimal('379.00'),
        'pages': 499,
        'rating': Decimal('4.4'),
        'is_best_seller': True,
        'published_date': datetime.date(2011, 10, 25),
    },
    # Self Help
    {
        'title': 'Atomic Habits',
        'author': 'James Clear',
        'category': 'Self Help',
        'description': 'The instant #1 New York Times bestseller. An easy and proven way to build good habits and break bad ones.',
        'price': Decimal('499.00'),
        'pages': 320,
        'rating': Decimal('4.9'),
        'is_best_seller': True,
        'is_featured': True,
        'is_audiobook': True,
        'published_date': datetime.date(2018, 10, 16),
    },
    {
        'title': 'The Power of Now',
        'author': 'Eckhart Tolle',
        'category': 'Self Help',
        'description': 'A guide to spiritual enlightenment. The Power of Now is a must-read for anyone looking to transform their life.',
        'price': Decimal('299.00'),
        'pages': 236,
        'rating': Decimal('4.3'),
        'is_new_arrival': True,
        'is_audiobook': True,
        'published_date': datetime.date(1997, 1, 1),
    },
    # Science & Technology
    {
        'title': 'A Brief History of Time',
        'author': 'Stephen Hawking',
        'category': 'Science & Technology',
        'description': 'From the Big Bang to black holes, Stephen Hawking\'s landmark work remains one of the most important science books ever written.',
        'price': Decimal('349.00'),
        'pages': 212,
        'rating': Decimal('4.7'),
        'is_best_seller': True,
        'is_audiobook': True,
        'published_date': datetime.date(1988, 4, 1),
    },
    {
        'title': 'The Code Book',
        'author': 'Simon Singh',
        'category': 'Science & Technology',
        'description': 'The evolution of secrecy from Mary, Queen of Scots, to quantum cryptography. A fascinating history of codes and code-breaking.',
        'price': Decimal('279.00'),
        'pages': 402,
        'rating': Decimal('4.2'),
        'is_new_arrival': True,
        'published_date': datetime.date(1999, 9, 1),
    },
    # Business
    {
        'title': 'Zero to One',
        'author': 'Peter Thiel',
        'category': 'Business',
        'description': 'Notes on startups, or how to build the future. The next Bill Gates will not build an operating system. The next Larry Page won\'t make a search engine.',
        'price': Decimal('399.00'),
        'pages': 224,
        'rating': Decimal('4.5'),
        'is_best_seller': True,
        'is_new_arrival': True,
        'published_date': datetime.date(2014, 9, 16),
    },
    # Mystery
    {
        'title': 'Gone Girl',
        'author': 'Gillian Flynn',
        'category': 'Mystery & Thriller',
        'description': 'On a warm summer morning in North Carthage, Missouri, it is Nick and Amy Dunne\'s fifth wedding anniversary. A psychological thriller to remember.',
        'price': Decimal('299.00'),
        'pages': 432,
        'rating': Decimal('4.1'),
        'is_best_seller': True,
        'is_audiobook': True,
        'published_date': datetime.date(2012, 6, 5),
    },
    {
        'title': 'The Silent Patient',
        'author': 'Alex Michaelides',
        'category': 'Mystery & Thriller',
        'description': 'A famous painter shoots her husband and then never speaks another word. A riveting psychological thriller that will keep you guessing.',
        'price': Decimal('349.00'),
        'pages': 368,
        'rating': Decimal('4.3'),
        'is_new_arrival': True,
        'published_date': datetime.date(2019, 2, 5),
    },
    # Romance
    {
        'title': 'The Notebook',
        'author': 'Nicholas Sparks',
        'category': 'Romance',
        'description': 'A story about a love so enduring and deep it transcends time. Set in 1940s North Carolina, a poor and passionate young man falls in love with a rich girl.',
        'price': Decimal('249.00'),
        'pages': 214,
        'rating': Decimal('4.2'),
        'is_best_seller': True,
        'published_date': datetime.date(1996, 10, 1),
    },
    # History
    {
        'title': 'Guns, Germs, and Steel',
        'author': 'Jared Diamond',
        'category': 'History',
        'description': 'Why did history unfold differently on different continents? Winner of the Pulitzer Prize, this remarkable book explains the rise of civilizations.',
        'price': Decimal('429.00'),
        'pages': 480,
        'rating': Decimal('4.4'),
        'is_new_arrival': True,
        'published_date': datetime.date(1997, 3, 1),
    },
    # Children
    {
        'title': 'Harry Potter and the Philosopher\'s Stone',
        'author': 'J.K. Rowling',
        'category': 'Children',
        'description': 'An orphan boy discovers he\'s a wizard and begins his education at Hogwarts School of Witchcraft and Wizardry.',
        'price': Decimal('299.00'),
        'pages': 332,
        'rating': Decimal('4.9'),
        'is_best_seller': True,
        'is_featured': True,
        'is_audiobook': True,
        'published_date': datetime.date(1997, 6, 26),
    },
]


class Command(BaseCommand):
    help = 'Load sample books and categories into the database'

    def handle(self, *args, **kwargs):
        self.stdout.write('Loading sample data...')

        # Create Categories
        category_map = {}
        for name, icon, desc in CATEGORIES:
            cat, created = Category.objects.get_or_create(
                slug=slugify(name),
                defaults={'name': name, 'icon': icon, 'description': desc}
            )
            if not created:
                cat.icon = icon
                cat.description = desc
                cat.save()
            category_map[name] = cat
            action = 'Created' if created else 'Updated'
            self.stdout.write(f'  {action} category: {name}')

        # Create Books
        for data in BOOKS:
            cat_name = data.pop('category')
            category = category_map.get(cat_name)
            if not category:
                self.stdout.write(self.style.WARNING(f'  Category not found: {cat_name}'))
                continue

            book, created = Book.objects.get_or_create(
                title=data['title'],
                author=data['author'],
                defaults={**data, 'category': category}
            )
            action = 'Created' if created else 'Skipped (exists)'
            self.stdout.write(f'  {action} book: {data["title"]}')
            data['category'] = cat_name  # restore for next iteration

        self.stdout.write(self.style.SUCCESS('\n✅ Sample data loaded successfully!'))
        self.stdout.write(f'   Categories: {Category.objects.count()}')
        self.stdout.write(f'   Books: {Book.objects.count()}')
        self.stdout.write('\n📌 Next steps:')
        self.stdout.write('   python manage.py createsuperuser')
        self.stdout.write('   python manage.py runserver')
