from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('books/', views.book_list, name='book_list'),
    path('books/<int:pk>/', views.book_detail, name='book_detail'),
    path('books/<int:pk>/ai-summary/', views.get_ai_summary, name='ai_summary'),
    path('category/<slug:slug>/', views.category_detail, name='category_detail'),
    path('best-sellers/', views.best_sellers, name='best_sellers'),
    path('new-arrivals/', views.new_arrivals, name='new_arrivals'),
    path('audiobooks/', views.audiobooks, name='audiobooks'),

    # Newsletter
    path('subscribe/', views.subscribe, name='subscribe'),

    # Cart
    path('cart/', views.cart_view, name='cart'),
    path('cart/add/<int:pk>/', views.add_to_cart, name='add_to_cart'),
    path('cart/update/<int:pk>/', views.update_cart, name='update_cart'),
    path('cart/remove/<int:pk>/', views.remove_from_cart, name='remove_from_cart'),

    # Checkout
    path('checkout/', views.checkout, name='checkout'),
    path('order/success/<int:pk>/', views.order_success, name='order_success'),
]
