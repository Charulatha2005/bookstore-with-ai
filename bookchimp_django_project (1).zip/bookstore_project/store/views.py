import json
import requests
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models import Q

from .models import Book, Category, Subscriber, CartItem, Order, OrderItem


# ─── Helpers ───────────────────────────────────────────────────────────────────

def get_or_create_session(request):
    if not request.session.session_key:
        request.session.create()
    return request.session.session_key


def get_cart_items(request):
    session_key = get_or_create_session(request)
    return CartItem.objects.filter(session_key=session_key).select_related('book')


# ─── Home ──────────────────────────────────────────────────────────────────────

def home(request):
    categories = Category.objects.all()
    best_sellers = Book.objects.filter(is_best_seller=True)[:6]
    new_arrivals = Book.objects.filter(is_new_arrival=True)[:6]
    featured = Book.objects.filter(is_featured=True)[:4]
    audiobooks = Book.objects.filter(is_audiobook=True)[:4]
    context = {
        'categories': categories,
        'best_sellers': best_sellers,
        'new_arrivals': new_arrivals,
        'featured': featured,
        'audiobooks': audiobooks,
    }
    return render(request, 'store/home.html', context)


# ─── Books ─────────────────────────────────────────────────────────────────────

def book_list(request):
    books = Book.objects.all()
    categories = Category.objects.all()

    # Filters
    category_slug = request.GET.get('category')
    search_query = request.GET.get('q', '')
    filter_type = request.GET.get('filter')
    sort = request.GET.get('sort', 'newest')

    if category_slug:
        books = books.filter(category__slug=category_slug)
    if search_query:
        books = books.filter(
            Q(title__icontains=search_query) |
            Q(author__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    if filter_type == 'bestseller':
        books = books.filter(is_best_seller=True)
    elif filter_type == 'new':
        books = books.filter(is_new_arrival=True)
    elif filter_type == 'audiobook':
        books = books.filter(is_audiobook=True)

    # Sorting
    if sort == 'price_asc':
        books = books.order_by('price')
    elif sort == 'price_desc':
        books = books.order_by('-price')
    elif sort == 'rating':
        books = books.order_by('-rating')
    else:
        books = books.order_by('-created_at')

    context = {
        'books': books,
        'categories': categories,
        'selected_category': category_slug,
        'search_query': search_query,
        'filter_type': filter_type,
        'sort': sort,
        'total_books': books.count(),
    }
    return render(request, 'store/book_list.html', context)


def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    related_books = Book.objects.filter(category=book.category).exclude(pk=pk)[:4]
    context = {
        'book': book,
        'related_books': related_books,
    }
    return render(request, 'store/book_detail.html', context)


# ─── AI Summary ────────────────────────────────────────────────────────────────

def get_ai_summary(request, pk):
    book = get_object_or_404(Book, pk=pk)
    api_key = settings.GEMINI_API_KEY

    if api_key == 'YOUR_GEMINI_API_KEY_HERE':
        return JsonResponse({
            'summary': (
                f"'{book.title}' by {book.author} is a captivating read from the {book.category.name} genre. "
                f"This book spans {book.pages} pages and offers readers an immersive experience. "
                f"[AI summary unavailable — please configure your GEMINI_API_KEY in settings.py to enable live AI-generated summaries.]"
            )
        })

    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={api_key}"
        prompt = (
            f"Give a concise, engaging 3-4 sentence summary of the book titled '{book.title}' "
            f"by {book.author} from the {book.category.name} genre. "
            f"Make it informative and enticing for potential readers."
        )
        payload = {"contents": [{"parts": [{"text": prompt}]}]}
        response = requests.post(url, json=payload, timeout=10)
        data = response.json()
        summary = data['candidates'][0]['content']['parts'][0]['text']
        return JsonResponse({'summary': summary})
    except Exception as e:
        return JsonResponse({
            'summary': (
                f"'{book.title}' by {book.author} is a compelling {book.category.name} book. "
                f"It promises to be an engaging read for book lovers. "
                f"(AI summary temporarily unavailable.)"
            )
        })


# ─── Newsletter ────────────────────────────────────────────────────────────────

@require_POST
def subscribe(request):
    email = request.POST.get('email', '').strip()
    if email:
        obj, created = Subscriber.objects.get_or_create(email=email)
        if created:
            messages.success(request, f'🎉 Welcome! {email} has been subscribed successfully.')
        else:
            messages.info(request, f'You are already subscribed with {email}.')
    else:
        messages.error(request, 'Please provide a valid email address.')
    return redirect(request.META.get('HTTP_REFERER', 'home'))


# ─── Cart ──────────────────────────────────────────────────────────────────────

def cart_view(request):
    cart_items = get_cart_items(request)
    total = sum(item.subtotal for item in cart_items)
    context = {
        'cart_items': cart_items,
        'total': total,
        'delivery': 49 if total > 0 else 0,
        'grand_total': total + (49 if total > 0 else 0),
    }
    return render(request, 'store/cart.html', context)


@require_POST
def add_to_cart(request, pk):
    book = get_object_or_404(Book, pk=pk)
    session_key = get_or_create_session(request)
    cart_item, created = CartItem.objects.get_or_create(session_key=session_key, book=book)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    messages.success(request, f'"{book.title}" added to cart!')

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        count = CartItem.objects.filter(session_key=session_key).count()
        return JsonResponse({'success': True, 'cart_count': count})

    return redirect(request.META.get('HTTP_REFERER', 'home'))


@require_POST
def update_cart(request, pk):
    session_key = get_or_create_session(request)
    cart_item = get_object_or_404(CartItem, session_key=session_key, book_id=pk)
    action = request.POST.get('action')
    if action == 'increase':
        cart_item.quantity += 1
        cart_item.save()
    elif action == 'decrease':
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
            cart_item.save()
        else:
            cart_item.delete()
    elif action == 'remove':
        cart_item.delete()
    return redirect('cart')


def remove_from_cart(request, pk):
    session_key = get_or_create_session(request)
    CartItem.objects.filter(session_key=session_key, book_id=pk).delete()
    messages.success(request, 'Item removed from cart.')
    return redirect('cart')


# ─── Checkout ──────────────────────────────────────────────────────────────────

def checkout(request):
    cart_items = get_cart_items(request)
    if not cart_items.exists():
        messages.warning(request, 'Your cart is empty.')
        return redirect('cart')

    total = sum(item.subtotal for item in cart_items)
    delivery = 49
    grand_total = total + delivery

    if request.method == 'POST':
        # Create order
        order = Order.objects.create(
            session_key=get_or_create_session(request),
            full_name=request.POST.get('full_name'),
            email=request.POST.get('email'),
            phone=request.POST.get('phone'),
            address=request.POST.get('address'),
            city=request.POST.get('city'),
            pincode=request.POST.get('pincode'),
            total_amount=grand_total,
            payment_method=request.POST.get('payment_method', 'COD'),
        )
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                book=item.book,
                quantity=item.quantity,
                price=item.book.price,
            )
        # Clear cart
        cart_items.delete()
        messages.success(request, f'🎉 Order #{order.pk} placed successfully!')
        return redirect('order_success', pk=order.pk)

    context = {
        'cart_items': cart_items,
        'total': total,
        'delivery': delivery,
        'grand_total': grand_total,
    }
    return render(request, 'store/checkout.html', context)


def order_success(request, pk):
    order = get_object_or_404(Order, pk=pk)
    return render(request, 'store/order_success.html', {'order': order})


# ─── Category Page ─────────────────────────────────────────────────────────────

def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    books = Book.objects.filter(category=category)
    context = {'category': category, 'books': books}
    return render(request, 'store/category_detail.html', context)


# ─── Best Sellers / New Arrivals ───────────────────────────────────────────────

def best_sellers(request):
    books = Book.objects.filter(is_best_seller=True)
    return render(request, 'store/book_list.html', {
        'books': books, 'page_title': '🏆 Best Sellers',
        'categories': Category.objects.all(),
    })


def new_arrivals(request):
    books = Book.objects.filter(is_new_arrival=True)
    return render(request, 'store/book_list.html', {
        'books': books, 'page_title': '🆕 New Arrivals',
        'categories': Category.objects.all(),
    })


def audiobooks(request):
    books = Book.objects.filter(is_audiobook=True)
    return render(request, 'store/book_list.html', {
        'books': books, 'page_title': '🎧 Audiobooks',
        'categories': Category.objects.all(),
    })
