#!/bin/bash
# BookChimp — Quick Setup Script
# Run this from inside the bookstore_project folder

set -e

echo ""
echo "╔══════════════════════════════════════╗"
echo "║   📚 BookChimp Setup Script          ║"
echo "╚══════════════════════════════════════╝"
echo ""

# 1. Install dependencies
echo "📦 Installing dependencies..."
pip install django pillow requests

echo ""
echo "🗄️  Running database migrations..."
python manage.py makemigrations store
python manage.py migrate

echo ""
echo "📖 Loading sample books and categories..."
python manage.py load_sample_data

echo ""
echo "👤 Creating superuser (admin panel access)..."
echo "   Enter credentials for the admin panel:"
python manage.py createsuperuser

echo ""
echo "════════════════════════════════════════"
echo "✅ Setup complete! Starting server..."
echo "════════════════════════════════════════"
echo ""
echo "🌐 Homepage:    http://127.0.0.1:8000/"
echo "🔐 Admin Panel: http://127.0.0.1:8000/admin/"
echo ""
echo "🤖 AI Summaries: Edit bookstore/settings.py"
echo "   and replace GEMINI_API_KEY with your key"
echo ""
python manage.py runserver
