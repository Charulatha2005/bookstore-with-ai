# 📚 BookChimp — Online Book Store (Django)

A full-stack online bookstore built with **Django**, featuring an admin panel, AI book summaries via Google Gemini, shopping cart, newsletter subscription, and more.

---

## 🚀 Quick Start

```bash
# 1. Navigate into the project folder
cd bookstore_project

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run migrations
python manage.py makemigrations store
python manage.py migrate

# 4. Load sample books & categories
python manage.py load_sample_data

# 5. Create admin user
python manage.py createsuperuser

# 6. Start the server
python manage.py runserver
```

Then open:
- 🌐 **Homepage**: http://127.0.0.1:8000/
- 🔐 **Admin Panel**: http://127.0.0.1:8000/admin/

---

## 🤖 Enable AI Book Summaries (Google Gemini)

1. Go to https://makersuite.google.com/app/apikey and generate an API key.
2. Open `bookstore/settings.py`
3. Replace:
   ```python
   GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY_HERE'
   ```
   with your actual key.

---

## 🗂️ Project Structure

```
bookstore_project/
├── manage.py
├── requirements.txt
├── setup.sh                        ← One-shot setup script
├── bookstore/
│   ├── settings.py                 ← Project settings (DB, Gemini key, etc.)
│   ├── urls.py                     ← Main URL routing
│   └── wsgi.py
└── store/                          ← Main app
    ├── models.py                   ← Category, Book, Subscriber, Cart, Order
    ├── views.py                    ← All view logic
    ├── urls.py                     ← App URL routes
    ├── admin.py                    ← Customized admin panel
    ├── context_processors.py       ← Cart count in navbar
    ├── management/
    │   └── commands/
    │       └── load_sample_data.py ← Sample data loader
    └── templates/store/
        ├── base.html               ← Base layout (navbar, footer)
        ├── home.html               ← Homepage
        ├── book_list.html          ← Books grid with filters
        ├── book_detail.html        ← Book detail + AI summary
        ├── cart.html               ← Shopping cart
        ├── checkout.html           ← Checkout form
        ├── order_success.html      ← Order confirmation
        ├── category_detail.html    ← Category view
        └── partials/
            └── book_card.html      ← Reusable book card
```

---

## ✨ Features

| Feature | Description |
|---|---|
| 🏠 Homepage | Hero section, best sellers, new arrivals, categories |
| 📚 Book Catalog | Filter by category, type, search, sort |
| 📖 Book Detail | Full details, related books, AI summary |
| 🤖 AI Summary | Google Gemini API generates summaries on demand |
| 🛒 Cart | Add/remove/update quantities |
| 💳 Checkout | Delivery form + dummy payment (COD, UPI, Card) |
| ✅ Order Success | Order confirmation page |
| 📧 Newsletter | Email subscription saved to DB |
| 🔐 Admin Panel | Full CRUD for Books, Categories, Orders, Subscribers |
| 🎧 Audiobooks | Separate section for audio versions |
| 🏆 Best Sellers | Featured bestseller section with badge |
| ✨ New Arrivals | Newly added books section |

---

## 🛠️ Admin Panel Capabilities

Log in at `/admin/` with your superuser credentials:

- **Books**: Add/edit/delete books, set as bestseller/new arrival/audiobook/featured, upload covers
- **Categories**: Manage categories with emoji icons and slugs
- **Subscribers**: View all newsletter emails, mark active/inactive, export
- **Orders**: View all orders, update status (Pending → Confirmed → Shipped → Delivered)
- **Cart Items**: Debug active carts

---

## 📦 Models

### `Category`
- `name`, `slug`, `description`, `icon` (emoji)

### `Book`
- `title`, `author`, `category`, `description`, `price`
- `cover_image`, `isbn`, `pages`, `language`, `published_date`
- `stock`, `rating`
- `is_best_seller`, `is_new_arrival`, `is_audiobook`, `is_featured`

### `Subscriber`
- `email`, `subscribed_at`, `is_active`

### `CartItem`
- `session_key`, `book`, `quantity`

### `Order` + `OrderItem`
- Full order with delivery address, payment method, status tracking

---

## 🎨 Tech Stack

- **Backend**: Python 3.x + Django 4.x
- **Database**: SQLite (default)
- **Frontend**: Bootstrap 5 + Google Fonts (Playfair Display + Inter)
- **AI**: Google Gemini API (generativelanguage.googleapis.com)
- **Icons**: Bootstrap Icons

---

## 📝 URL Routes

| URL | View | Name |
|---|---|---|
| `/` | Home | `home` |
| `/books/` | Book list + filters | `book_list` |
| `/books/<id>/` | Book detail | `book_detail` |
| `/books/<id>/ai-summary/` | AI summary (AJAX) | `ai_summary` |
| `/category/<slug>/` | Category page | `category_detail` |
| `/best-sellers/` | Best sellers | `best_sellers` |
| `/new-arrivals/` | New arrivals | `new_arrivals` |
| `/audiobooks/` | Audiobooks | `audiobooks` |
| `/subscribe/` | Newsletter subscribe | `subscribe` |
| `/cart/` | Cart | `cart` |
| `/cart/add/<id>/` | Add to cart | `add_to_cart` |
| `/cart/update/<id>/` | Update quantity | `update_cart` |
| `/cart/remove/<id>/` | Remove item | `remove_from_cart` |
| `/checkout/` | Checkout | `checkout` |
| `/order/success/<id>/` | Order success | `order_success` |
| `/admin/` | Admin panel | — |

---

## 💡 Tips

- To add book cover images, upload them via the admin panel `/admin/store/book/`
- Change `TIME_ZONE = 'Asia/Kolkata'` in `settings.py` for Indian timezone
- For production, set `DEBUG = False` and configure `ALLOWED_HOSTS`
- The cart uses Django sessions — no login required

---

*Built with ❤️ using Django & Bootstrap — BookChimp © 2024*
